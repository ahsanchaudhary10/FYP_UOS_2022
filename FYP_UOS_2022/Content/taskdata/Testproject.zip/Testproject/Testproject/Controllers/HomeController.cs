﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Testproject.Models;
using Testproject.TestDependency;

namespace Testproject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        Test test;

        public HomeController(ILogger<HomeController> logger,Test test)
        {
            this.test = test;
            _logger = logger;
        }

        public IActionResult Index()
        {
          string msg=  test.callmsg();
            
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}