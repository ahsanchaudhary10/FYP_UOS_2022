﻿using Testproject.Models;
using Testproject.Reposittrytest.IRepositry;

namespace Testproject.Reposittrytest.Implementations
{
    public class CategoryRepositry : Repositry<Category>, IcategoryRepositry
    {
        public CategoryRepositry(Db_ShopContext db) : base(db)
        {
        }
    }
}
