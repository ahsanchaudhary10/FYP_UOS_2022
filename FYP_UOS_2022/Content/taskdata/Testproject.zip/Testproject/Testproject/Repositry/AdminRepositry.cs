﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using Testproject.Models;
using Testproject.Repositry.IRepositry;

namespace Testproject.Repositry
{
    public class AdminRepositry : IAdminRepositry
    {


        private Db_ShopContext db;
        private DbSet<Admin> dbset;

        public AdminRepositry(Db_ShopContext db)
        {
            this.db = db;
            dbset = db.Set<Admin>();
        }

        public void Add(Admin item)
        {
            dbset.Add(item);
            db.SaveChanges();
        }

        public IEnumerable<Admin> GetAll()
        {
          return  dbset.ToList();
        }

        public Admin GetFirstOrDefault(Expression<Func<Admin, bool>> predicate)
        {
            return dbset.FirstOrDefault(predicate);
        }

        public void Remove(Admin item)
        {
            dbset.Remove(item);
            db.SaveChanges();
        }

        public Admin Update(Admin item)
        {
           dbset.Update(item);
            db.SaveChanges();
            return item;
        }
    }
}
