﻿using System.Linq.Expressions;
using Testproject.Models;

namespace Testproject.Repositry.IRepositry
{
    public interface IAdminRepositry
    {
        IEnumerable<Admin> GetAll();
        void Add(Admin item);

        void Remove(Admin item);
        Admin Update(Admin item);

        Admin GetFirstOrDefault(Expression<Func<Admin, bool>> predicate);


    }
}
