﻿using Testproject.Models;
using Testproject.Reposittrytest.Implementations;

namespace Testproject.Reposittrytest.IRepositry
{
    public interface IAdminRepositry : IRepositry<Admin>
    {
    }
}
