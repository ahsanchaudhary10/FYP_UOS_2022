﻿using Testproject.Models;
using Testproject.Reposittrytest.IRepositry;

namespace Testproject.Reposittrytest.Implementations
{
    public class ProductRepositry : Repositry<Product>, IProductRepositry
    {
        public ProductRepositry(Db_ShopContext db) : base(db)
        {
        }
    }
}
