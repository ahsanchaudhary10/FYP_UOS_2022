﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Testproject.Models
{
    public partial class Db_ShopContext : DbContext
    {
        public Db_ShopContext()
        {
        }

        public Db_ShopContext(DbContextOptions<Db_ShopContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admins { get; set; } = null!;
        public virtual DbSet<Category> Categories { get; set; } = null!;
        public virtual DbSet<Order> Orders { get; set; } = null!;
        public virtual DbSet<OrderDetail> OrderDetails { get; set; } = null!;
        public virtual DbSet<Product> Products { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            /*if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-2BBRS0S\\SQLEXPRESS;Database=Db_Shop;Trusted_Connection=True;");
            }*/
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.ToTable("ADmin");

                entity.Property(e => e.AdminId).HasColumnName("Admin_id");

                entity.Property(e => e.AdminEmail)
                    .HasMaxLength(50)
                    .HasColumnName("Admin_Email");

                entity.Property(e => e.AdminName)
                    .HasMaxLength(50)
                    .HasColumnName("Admin_Name");

                entity.Property(e => e.AdminPassword)
                    .HasMaxLength(50)
                    .HasColumnName("Admin_Password");

                entity.Property(e => e.AdminPhone)
                    .HasMaxLength(50)
                    .HasColumnName("Admin_Phone");
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("Category");

                entity.Property(e => e.CategoryId).HasColumnName("Category_id");

                entity.Property(e => e.CategoryName)
                    .HasMaxLength(50)
                    .HasColumnName("Category_Name");
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("Order");

                entity.Property(e => e.OrderId).HasColumnName("Order_id");

                entity.Property(e => e.OrderAddress).HasColumnName("Order_Address");

                entity.Property(e => e.OrderContact)
                    .HasMaxLength(50)
                    .HasColumnName("Order_Contact");

                entity.Property(e => e.OrderDatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("Order_Datetime");

                entity.Property(e => e.OrderEmail)
                    .HasMaxLength(50)
                    .HasColumnName("Order_Email");

                entity.Property(e => e.OrderName)
                    .HasMaxLength(50)
                    .HasColumnName("Order_Name");

                entity.Property(e => e.OrderPaymentMethod)
                    .HasMaxLength(50)
                    .HasColumnName("Order_Payment_Method");

                entity.Property(e => e.OrderStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Order_Status");

                entity.Property(e => e.OrderType)
                    .HasMaxLength(50)
                    .HasColumnName("Order_Type");
            });

            modelBuilder.Entity<OrderDetail>(entity =>
            {
                entity.HasKey(e => e.OdId);

                entity.ToTable("Order_Detail");

                entity.Property(e => e.OdId).HasColumnName("Od_id");

                entity.Property(e => e.OrderFid).HasColumnName("Order_Fid");

                entity.Property(e => e.ProductFid).HasColumnName("Product_fid");

                entity.Property(e => e.PurchasePrice)
                    .HasColumnType("numeric(18, 2)")
                    .HasColumnName("Purchase_Price");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.SalePrice)
                    .HasColumnType("numeric(18, 2)")
                    .HasColumnName("Sale_Price");

                entity.HasOne(d => d.OrderF)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.OrderFid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Order_Detail_Order");

                entity.HasOne(d => d.ProductF)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.ProductFid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Order_Detail_Products");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.ProductId).HasColumnName("Product_id");

                entity.Property(e => e.CategoryFid).HasColumnName("Category_Fid");

                entity.Property(e => e.ProductDescription).HasColumnName("Product_Description");

                entity.Property(e => e.ProductDiscount).HasColumnName("Product_Discount");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(50)
                    .HasColumnName("Product_Name");

                entity.Property(e => e.ProductPicture).HasColumnName("Product_Picture");

                entity.Property(e => e.ProductPurchasePrice)
                    .HasColumnType("numeric(18, 2)")
                    .HasColumnName("Product_PurchasePrice");

                entity.Property(e => e.ProductSalePrice)
                    .HasColumnType("numeric(18, 2)")
                    .HasColumnName("Product_SalePrice");

                entity.HasOne(d => d.CategoryF)
                    .WithMany(p => p.Products)
                    .HasForeignKey(d => d.CategoryFid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Products_Category");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
