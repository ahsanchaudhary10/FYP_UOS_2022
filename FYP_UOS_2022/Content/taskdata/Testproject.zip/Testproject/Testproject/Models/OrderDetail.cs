﻿using System;
using System.Collections.Generic;

namespace Testproject.Models
{
    public partial class OrderDetail
    {
        public int OdId { get; set; }
        public int ProductFid { get; set; }
        public int Quantity { get; set; }
        public int OrderFid { get; set; }
        public decimal SalePrice { get; set; }
        public decimal PurchasePrice { get; set; }

        public virtual Order OrderF { get; set; } = null!;
        public virtual Product ProductF { get; set; } = null!;
    }
}
