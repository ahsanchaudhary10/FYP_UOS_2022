﻿using Testproject.Models;

namespace Testproject.Reposittrytest.IRepositry
{
    public interface IcategoryRepositry : IRepositry<Category>
    {
    }
}
