﻿using Testproject.TestDependency.Interface;

namespace Testproject.TestDependency
{
    public class Message : IMessage
    {
        public string writemessage()
        {
            return "Hi World";
        }
    }
}
