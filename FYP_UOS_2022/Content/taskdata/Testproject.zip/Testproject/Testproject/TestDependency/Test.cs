﻿using Testproject.TestDependency.Interface;

namespace Testproject.TestDependency
{
    public class Test
    {
        IMessage message;
        public Test(IMessage message)
        {
            this.message = message;
        }
        public string callmsg()
        {
          return  message.writemessage();
        }
    }
}
