﻿using Testproject.Models;
using Testproject.Reposittrytest.IRepositry;

namespace Testproject.Reposittrytest.Implementations
{
    public class AdminRepositry : Repositry<Admin>,IAdminRepositry
    {
        public AdminRepositry(Db_ShopContext db) : base(db)
        {
        }
    }
}
