﻿using System;
using System.Collections.Generic;

namespace Testproject.Models
{
    public partial class Product
    {
        public Product()
        {
            OrderDetails = new HashSet<OrderDetail>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; } = null!;
        public decimal ProductSalePrice { get; set; }
        public string ProductDescription { get; set; } = null!;
        public int? ProductDiscount { get; set; }
        public string ProductPicture { get; set; } = null!;
        public decimal ProductPurchasePrice { get; set; }
        public int CategoryFid { get; set; }

        public virtual Category CategoryF { get; set; } = null!;
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
