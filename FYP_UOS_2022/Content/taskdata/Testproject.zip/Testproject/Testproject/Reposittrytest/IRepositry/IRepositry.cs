﻿using System.Linq.Expressions;

namespace Testproject.Reposittrytest
{
    public interface IRepositry<T> where T : class
    {
        IEnumerable<T> GetAll();
        void Add(T item);

        void Remove(T item);

        T GetFirstOrDefault(Expression<Func<T, bool>> predicate);

        T Update(T item);

    }
}
