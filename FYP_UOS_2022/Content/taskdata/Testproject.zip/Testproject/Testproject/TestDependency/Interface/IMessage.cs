﻿namespace Testproject.TestDependency.Interface
{

    public delegate IMessage ServiceResolver(string key);
    public interface IMessage
    {

        string writemessage();
        
    }
}
