﻿using System;
using System.Collections.Generic;

namespace Testproject.Models
{
    public partial class Order
    {
        public Order()
        {
            OrderDetails = new HashSet<OrderDetail>();
        }

        public int OrderId { get; set; }
        public string OrderName { get; set; } = null!;
        public string OrderAddress { get; set; } = null!;
        public string OrderContact { get; set; } = null!;
        public string? OrderEmail { get; set; }
        public string OrderPaymentMethod { get; set; } = null!;
        public DateTime OrderDatetime { get; set; }
        public string OrderStatus { get; set; } = null!;
        public string OrderType { get; set; } = null!;

        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
