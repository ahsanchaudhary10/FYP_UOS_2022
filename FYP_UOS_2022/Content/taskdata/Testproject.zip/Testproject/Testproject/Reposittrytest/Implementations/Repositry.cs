﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using Testproject.Models;

namespace Testproject.Reposittrytest.Implementations
{
    public class Repositry<T> : IRepositry<T> where T : class
    {
        private Db_ShopContext db;
        private DbSet<T> dbSet;

        public Repositry(Db_ShopContext db)
        {
            this.db = db;
            this.dbSet = db.Set<T>();
        }

        public void Add(T item)
        {
            //db.Set<T>().Add(item);
            dbSet.Add(item);
            db.SaveChanges();
        }

        public IEnumerable<T> GetAll()
        {
            return dbSet.ToList();
        }

        public T GetFirstOrDefault(Expression<Func<T, bool>> predicate)
        {
            T? t = dbSet.FirstOrDefault(predicate);
            if (t == null)
            {
                throw new NullReferenceException();
            }
            return t;

        }

        public void Remove(T item)
        {
            T? t = dbSet.Find(item);
            if (t == null)
                throw new NullReferenceException();
            dbSet.Remove(t);
            db.SaveChanges();
        }

        public T Update(T item)
        {
            dbSet.Update(item);
            db.SaveChanges();
            return item;
        }

       
    }
}
